# CodeAlpha DevOps Internship

## Task 4: Web Server using Docker

### Project Description
This project deploys a simple HTML website inside a Docker container using the Nginx web server.

### Technologies Used
- HTML
- Docker
- Nginx
- Visual Studio Code

### Project Files
- index.html
- Dockerfile
- README.md

### How to Run

Build the Docker image:

```bash
docker build -t codealpha-webserver .
```

Run the container:

```bash
docker run -d -p 8080:80 --name codealpha-webserver codealpha-webserver
```

Open http://localhost:8080 in your browser.

### Learning Outcomes
- Docker image creation
- Container execution
- Port mapping
- Web server deployment
CodeAlpha DevOps Internship

Project: Web Server using Docker

This project demonstrates how to build and run a simple web server using Docker.

Technologies Used

- HTML
- Docker
- Nginx

Steps to Run

1. Build the Docker image:
   "docker build -t codealpha-webserver ."
2. Run the Docker container:
   "docker run -d -p 8080:80 --name codealpha-webserver codealpha-webserver"
3. Open your browser and visit:
   "http://localhost:8080"

Output

A simple website displaying the CodeAlpha DevOps Internship page.

Author

CodeAlpha DevOps Internship Project
